using Microsoft.VisualStudio.TestTools.UnitTesting;
using Azenix;
using System.IO;
using System.Linq;
using System;
using System.Collections.Generic;

namespace TestProject
{
    [TestClass]
    public class UnitTest1
    {   
        [TestMethod]
        public void numberOfIP()
        {
            Azenix.AzenixLogParse a = new Azenix.AzenixLogParse();
            var results = File.ReadAllLines("example-data.log");
            int ip = a.extractIP(results).Distinct().Count();
            Assert.AreEqual(11,ip);
        }
        [TestMethod]
        public void topVisitedURL()
        {
            Azenix.AzenixLogParse a = new Azenix.AzenixLogParse();
            var results = File.ReadAllLines("example-data.log");
            var top3VisitedURL = new Dictionary<String, int>();
            var actualTop3URL = new Dictionary<String, int>();
            var expectedTop3URL = new Dictionary<String, int>
            {
                {"/docs/manage-websites/", 2},
                {"/intranet-analytics/", 1 },
                {"http://example.net/faq/", 1}
            };
            top3VisitedURL = a.top3URL(results);

            foreach (var item in top3VisitedURL.OrderByDescending(r => r.Value).Take(3))
            {
                actualTop3URL.Add(item.Key, item.Value);
            }

            CollectionAssert.AreEqual(actualTop3URL.OrderBy(kv => kv.Key).ToList(),
                expectedTop3URL.OrderBy(kv => kv.Key).ToList());
        }
        [TestMethod]
        public void topActiveIP()
        {
            Azenix.AzenixLogParse a = new Azenix.AzenixLogParse();
            var results = File.ReadAllLines("example-data.log");
            
            var top3ActiveIP = new Dictionary<String, int>();
            var actualTop3ActiveIP = new Dictionary<String, int>();
            var expectedTop3ActiveIP = new Dictionary<String, int>
            {
                {"168.41.191.40", 4},
                {"177.71.128.21", 3 },
                {"50.112.00.11", 3}
            };
            top3ActiveIP = a.top3IP(results, a.extractIP(results));

            foreach (var item in top3ActiveIP.OrderByDescending(r => r.Value).Take(3))
            {
                actualTop3ActiveIP.Add(item.Key, item.Value);
            }

            CollectionAssert.AreEqual(actualTop3ActiveIP.OrderBy(kv => kv.Key).ToList(),
                expectedTop3ActiveIP.OrderBy(kv => kv.Key).ToList());


        }
    }
}