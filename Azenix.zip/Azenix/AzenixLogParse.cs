﻿

namespace Azenix
{
    public class AzenixLogParse
    {
        static void Main(string[] args)
        {
            var results = File.ReadAllLines("example-data.log");
            AzenixLogParse obj = new AzenixLogParse();

            String [] extractIP =obj.extractIP(results);
            Console.WriteLine("Unique IP: " + extractIP.Distinct().Count());
            obj.top3URL(results);
            obj.top3IP(results, extractIP);
        }
        public string[] extractIP (string[] results)
        {
            String[] uniqueIP = new String[results.Length];
            int i = 0;
            // Extract IP address from file.
            foreach (var line in results)
            {
                uniqueIP[i] = line.Split(' ')[0];
                i++;
            }
            return uniqueIP;
        }

        public Dictionary <String,int> top3URL (string[] results)
        {
            String[] listOfURL = new String[results.Length];
            String[] uniqueIP = new String[results.Length];
            var urlCount = new Dictionary<String, int>();
            var ipCount = new Dictionary<String, int>();
            int i = 0;
            //Extract list of URL.
            foreach (var line in results)
            {
                listOfURL[i] = line.Split(" \"GET ")[1].Split(' ')[0];
                i++;
            }
            //Put all the URL in a dictionary.
            foreach (var url in listOfURL)
            {
                urlCount.TryGetValue(url, out int count);
                urlCount[url] = count + 1;
            }

            Console.WriteLine("\nTop 3 most visited URLs");
            foreach (var item in urlCount.OrderByDescending(r => r.Value).Take(3))
            {
                Console.WriteLine("URL name: {0} Count: {1}", item.Key, item.Value);
            }
            return urlCount;
        }
        public Dictionary<String,int> top3IP (string[] results , string[] uniqueIP)
        {
            var ipCount = new Dictionary<String, int>();
            int i = 0;

            //Extract all IP address to a dictionary.
            foreach (var ip in uniqueIP)
            {
                ipCount.TryGetValue(ip, out int count);
                ipCount[ip] = count + 1;
            }

            //Sort and print IP
            Console.WriteLine("\nTop 3 active IP address:");
            foreach (var item in ipCount.OrderByDescending(r => r.Value).Take(3))
            {
                Console.WriteLine("IP address: {0} Count: {1}", item.Key, item.Value);
            }
            return ipCount;
        }
    }
}